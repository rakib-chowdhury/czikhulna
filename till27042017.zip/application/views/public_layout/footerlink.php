
<script src="http://www.youtube.com/player_api" id="YTAPI"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>-->
<!--datepicker-->
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/bootstrap-datepicker.js"></script>

<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/bootstrap.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/jquery.migrate.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/jquery.appear.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/jquery.flexslider.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/retina-1.1.0.min.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/jquery.bxslider.min.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/plugins-scroll.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/waypoint.min.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/smooth.scroll.min.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/highcharts.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/highcharts.js"></script>

<!-- jQuery KenBurn Slider  -->
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="<?= base_url().'public_assets/'?>js/script.js"></script>

<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.js"></script>