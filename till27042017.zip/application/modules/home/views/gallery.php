<?php $bn_digits = array('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'); ?>

<body>
<!-- Container -->
<div id="container">
    <?php $this->load->view('public_layout/header'); ?>
    <link rel='stylesheet' href='{{url('uploads/')}}/unitegallery/css/unite-gallery.css' type='text/css'/>
    <link rel='stylesheet' href='{{url('uploads/')}}/unitegallery/themes/default/ug-theme-default.css'
          type='text/css'/>
    <!-- content ================================================== -->
    <div id="content">
        <form onsubmit="return idea_ckeck()" action="<?= site_url('home/idea_box_post') ?>" method="post">
            <!-- Page Banner -->
            <div class="page-banner about-banner">
                <div class="container">
                    <ul class="page-tree">
                        <li><a href="<?= site_url('home') ?>">CZI KHULNA</a></li>
                        <li><a href="<?= site_url('home/gallery') ?>">গ্যালারী</a></li>
                    </ul>
                </div>
            </div>

<!--            <h1 class="page-title about-title"><span style="color: whitesmoke; background: #8bc541;">গ্যালারী/span>-->
<!--            </h1>-->
            <h1 class="page-title about-title"><span style="color: whitesmoke; background: #8bc541;">গ্যালারীতে আপনাকে স্বাগতম</span>
            </h1>

            <!-- accord - skills with background image -->
            <div class="accord-skills white-back">
                <div class="accord-skills-container container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-lg-10 col-lg-offset-1 col-xs-12">
                            <div class="accordion-box triggerAnimation animated" data-animate="fadeInLeft">
                                <div class="content_info">
        <div class="padding-bottom-mini">
            <!-- Container Area - Boxes Services -->
            <div class="container">
                <div class="row" style="text-align: center">
                    <div id="gallery" class="center-block" style="display:none;">

                        <img alt="Preview Image 1"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb1.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image1.jpg"
                             data-description="Preview Image 1 Description">

                        <img alt="Preview Image 2"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb2.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image2.jpg"
                             data-description="Preview Image 2 Description">

                        <img alt="Youtube Video"
                             data-type="youtube"
                             data-videoid="A3PDXmYoF5U"
                             data-description="You can include youtube videos easily!">

                        <img alt="Preview Image 3"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb3.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image3.jpg"
                             data-description="Preview Image 3 Description">

                        <img alt="Vimeo Video"
                             data-type="vimeo"
                             src="http://i.vimeocdn.com/video/447294219_200x150.jpg"
                             data-image="http://i.vimeocdn.com/video/447294219_640.jpg"
                             data-videoid="73234449"
                             data-description="This gallery can also play vimeo videos!">

                        <img alt="Preview Image 4"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb4.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image4.jpg"
                             data-description="Preview Image 4 Description">

                        <img alt="Html5 Video"
                             src="{{url('public/img/')}}/gallery/thumbs/html5_video.png"
                             data-type="html5video"
                             data-image="http://video-js.zencoder.com/oceans-clip.png"
                             data-videoogv="http://video-js.zencoder.com/oceans-clip.ogv"
                             data-videowebm="http://video-js.zencoder.com/oceans-clip.webm"
                             data-videomp4="http://video-js.zencoder.com/oceans-clip.mp4"
                             data-description="This is html5 video demo played by mediaelement2 player">

                        <img alt="Preview Image 5"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb1.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image1.jpg"
                             data-description="Preview Image 5 Description">

                        <img alt="Wistia Video"
                             src="{{url('public/img/')}}/gallery/thumbs/wistia_video.jpg"
                             data-type="wistia"
                             data-image="{{url('public/img/')}}/gallery/big/wistia_video.jpg"
                             data-videoid="9oedgxuciv"
                             data-description="Hey, the gallery plays Wistia videos too!">

                        <img alt="Preview Image 6"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb2.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image2.jpg"
                             data-description="Preview Image 6 Description">


                        <img alt="Sound Cloud Track"
                             src="{{url('public/img/')}}/gallery/thumbs/sound_cloud.jpg"
                             data-type="soundcloud"
                             data-image="{{url('public/img/')}}/gallery/thumbs/sound_cloud.jpg"
                             data-trackid="8390970"
                             data-description="This gallery can play a soundcloud track">


                        <img alt="Preview Image 7"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb3.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image3.jpg"
                             data-description="Preview Image 7 Description">


                        <img alt="Preview Image 8"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb4.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image4.jpg"
                             data-description="Preview Image 8 Description">

                        <img alt="Preview Image 9"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb1.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image1.jpg"
                             data-description="Preview Image 9 Description">

                        <img alt="Preview Image 10"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb2.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image2.jpg"
                             data-description="Preview Image 10 Description">

                        <img alt="Preview Image 11"
                             src="{{url('public/img/')}}/gallery/thumbs/thumb3.jpg"
                             data-image="{{url('public/img/')}}/gallery/big/image3.jpg"
                             data-description="Preview Image 11 Description">

                    </div>
                </div>
            </div>
            <!-- End Container Area - Boxes Services -->
        </div>
    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- End content -->
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-common-libraries.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-functions.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-thumbsgeneral.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-thumbsstrip.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-touchthumbs.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-panelsbase.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-strippanel.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-gridpanel.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-thumbsgrid.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-tiles.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-tiledesign.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-avia.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-slider.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-sliderassets.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-touchslider.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-zoomslider.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-video.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-gallery.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-lightbox.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-carousel.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/js/ug-api.js'></script>
    <script type='text/javascript' src='{{url('public/')}}/js/libs/unitegallery/themes/default/ug-theme-default.js'></script>
    <script type="text/javascript">

        jQuery(document).ready(function () {

            jQuery("#gallery").unitegallery();

        });

    </script>
    <?php $this->load->view('public_layout/footer'); ?>
</div>


<!-- End Container -->
<?php $this->load->view('public_layout/footerlink'); ?>

</body>
</html>